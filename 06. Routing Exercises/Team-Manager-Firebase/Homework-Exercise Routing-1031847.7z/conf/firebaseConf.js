  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyBaJqWmSUKgV_656R0SqkG8aLhyUINfrek",
    authDomain: "softuni-afab5.firebaseapp.com",
    databaseURL: "https://softuni-afab5.firebaseio.com",
    projectId: "softuni-afab5",
    storageBucket: "softuni-afab5.appspot.com",
    messagingSenderId: "910373312656",
    appId: "1:910373312656:web:1686cb040e9986b910a015"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
